import java.util.Scanner;

public class Main {

    public static void main(String[] args) {

        Scanner scanner = new Scanner(System.in);
        SistemaFiscal sistema = new SistemaFiscal();

        boolean continuar = true;

        while (continuar) {
            System.out.println("\n================================");
            System.out.println(" SAT FINAL GABRIEL - SISTEMA FISCAL");
            System.out.println("================================");
            System.out.println("1. Registrar solicitud de acceso");
            System.out.println("2. Generar reporte de auditoria");
            System.out.println("3. Salir");
            System.out.print("Seleccione una opcion: ");

            int opcion = scanner.nextInt();
            scanner.nextLine();

            switch (opcion) {
                case 1:
                    Usuario usuario = crearUsuario(scanner);
                    RecursoFiscal recurso = crearRecurso(scanner);
                    String accion = elegirAccion(scanner);

                    SolicitudAcceso solicitud =
                            new SolicitudAcceso(usuario, recurso, accion);

                    sistema.procesarSolicitud(solicitud);
                    break;

                case 2:
                    sistema.generarReporte();
                    break;

                case 3:
                    continuar = false;
                    System.out.println("Sistema finalizado.");
                    break;

                default:
                    System.out.println("Opcion no valida.");
                    break;
            }
        }

        scanner.close();
    }

    private static Usuario crearUsuario(Scanner scanner) {
        System.out.println("\nSeleccione usuario:");
        System.out.println("1. Gabriel");
        System.out.println("2. Diana");
        System.out.println("3. Mariana");
        System.out.println("4. Ricardo");
        System.out.println("5. Peter");
        System.out.print("Opcion: ");

        int opcion = scanner.nextInt();
        scanner.nextLine();

        switch (opcion) {
            case 1:
                return new Usuario("Gabriel", new Rol("Administrador", true));
            case 2:
                return new Usuario("Diana", new Rol("Auditora", false));
            case 3:
                return new Usuario("Mariana", new Rol("Supervisora", true));
            case 4:
                return new Usuario("Ricardo", new Rol("Analista", false));
            case 5:
                return new Usuario("Peter", new Rol("Tecnico", false));
            default:
                System.out.println("Usuario no valido. Se asigna Gabriel por defecto.");
                return new Usuario("Gabriel", new Rol("Administrador", true));
        }
    }

    private static RecursoFiscal crearRecurso(Scanner scanner) {
        System.out.println("\nSeleccione recurso fiscal:");
        System.out.println("1. Declaraciones");
        System.out.println("2. Pagos");
        System.out.println("3. Auditorias");
        System.out.println("4. Registros fiscales");
        System.out.print("Opcion: ");

        int opcion = scanner.nextInt();
        scanner.nextLine();

        switch (opcion) {
            case 1:
                return new RecursoFiscal("Declaraciones");
            case 2:
                return new RecursoFiscal("Pagos");
            case 3:
                return new RecursoFiscal("Auditorias");
            case 4:
                return new RecursoFiscal("Registros fiscales");
            default:
                System.out.println("Recurso no valido. Se asigna Declaraciones por defecto.");
                return new RecursoFiscal("Declaraciones");
        }
    }

    private static String elegirAccion(Scanner scanner) {
        System.out.println("\nSeleccione accion:");
        System.out.println("1. CONSULTAR");
        System.out.println("2. MODIFICAR");
        System.out.println("3. ELIMINAR");
        System.out.println("4. VALIDAR");
        System.out.print("Opcion: ");

        int opcion = scanner.nextInt();
        scanner.nextLine();

        switch (opcion) {
            case 1:
                return "CONSULTAR";
            case 2:
                return "MODIFICAR";
            case 3:
                return "ELIMINAR";
            case 4:
                return "VALIDAR";
            default:
                System.out.println("Accion no valida. Se asigna CONSULTAR por defecto.");
                return "CONSULTAR";
        }
    }
}
