import java.util.ArrayList;

public class SistemaFiscal {

    private ArrayList<EventoAuditoria> eventos;

    public SistemaFiscal() {
        eventos = new ArrayList<>();
    }

    public void procesarSolicitud(SolicitudAcceso solicitud) {

        Usuario usuario = solicitud.getUsuario();
        String accion = solicitud.getAccion();
        String resultado = validarAcceso(usuario, accion);

        EventoAuditoria evento = new EventoAuditoria(
                usuario.getNombre(),
                usuario.getRol().getNombre(),
                solicitud.getRecurso().getNombre(),
                accion,
                resultado
        );

        eventos.add(evento);

        System.out.println("\n----- RESULTADO DE LA SOLICITUD -----");
        evento.mostrarEvento();
    }

    private String validarAcceso(Usuario usuario, String accion) {

        if (usuario.getRol().getNombre().equals("Administrador")) {
            return "ACCESO PERMITIDO";
        }

        if (usuario.getRol().getNombre().equals("Supervisora")
                && (accion.equals("CONSULTAR") || accion.equals("VALIDAR"))) {
            return "ACCESO PERMITIDO CON VALIDACION";
        }

        if (accion.equals("CONSULTAR")) {
            return "ACCESO LIMITADO A CONSULTA";
        }

        return "ACCESO DENEGADO";
    }

    public void generarReporte() {

        System.out.println("\n========== REPORTE DE AUDITORIA ==========");

        if (eventos.isEmpty()) {
            System.out.println("No hay eventos registrados.");
            return;
        }

        int permitidos = 0;
        int denegados = 0;

        for (EventoAuditoria evento : eventos) {
            evento.mostrarEvento();
            System.out.println("--------------------------------");

            if (evento.getResultado().contains("DENEGADO")) {
                denegados++;
            } else {
                permitidos++;
            }
        }

        System.out.println("Total de eventos: " + eventos.size());
        System.out.println("Accesos permitidos o limitados: " + permitidos);
        System.out.println("Accesos denegados: " + denegados);
    }
}
