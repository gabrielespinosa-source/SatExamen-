public class EventoAuditoria {

    private String usuario;
    private String rol;
    private String recurso;
    private String accion;
    private String resultado;

    public EventoAuditoria(String usuario, String rol, String recurso,
                           String accion, String resultado) {
        this.usuario = usuario;
        this.rol = rol;
        this.recurso = recurso;
        this.accion = accion;
        this.resultado = resultado;
    }

    public String getUsuario() {
        return usuario;
    }

    public String getResultado() {
        return resultado;
    }

    public void mostrarEvento() {
        System.out.println("Usuario: " + usuario);
        System.out.println("Rol: " + rol);
        System.out.println("Recurso: " + recurso);
        System.out.println("Accion: " + accion);
        System.out.println("Resultado: " + resultado);
    }
}
