public class SolicitudAcceso {

    private Usuario usuario;
    private RecursoFiscal recurso;
    private String accion;

    public SolicitudAcceso(Usuario usuario, RecursoFiscal recurso, String accion) {
        this.usuario = usuario;
        this.recurso = recurso;
        this.accion = accion;
    }

    public Usuario getUsuario() {
        return usuario;
    }

    public RecursoFiscal getRecurso() {
        return recurso;
    }

    public String getAccion() {
        return accion;
    }
}
