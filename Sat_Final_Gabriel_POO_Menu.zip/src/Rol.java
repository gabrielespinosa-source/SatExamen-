public class Rol {

    private String nombre;
    private boolean permisoEspecial;

    public Rol(String nombre, boolean permisoEspecial) {
        this.nombre = nombre;
        this.permisoEspecial = permisoEspecial;
    }

    public String getNombre() {
        return nombre;
    }

    public boolean tienePermisoEspecial() {
        return permisoEspecial;
    }
}
