
public class ReporteAuditoria {

    public void generarReporte() {

        System.out.println("--------------------------------");
        System.out.println("REPORTE FINAL");
        System.out.println("Solicitudes procesadas correctamente.");
        System.out.println("Sistema funcionando sin errores.");
    }
}
