
public class EventoAuditoria {

    private String usuario;
    private String accion;
    private String resultado;

    public EventoAuditoria(String usuario,
                           String accion,
                           String resultado) {

        this.usuario = usuario;
        this.accion = accion;
        this.resultado = resultado;
    }

    public void mostrarEvento() {

        System.out.println("Usuario: " + usuario);
        System.out.println("Accion: " + accion);
        System.out.println("Resultado: " + resultado);
    }
}
