
public class RecursoFiscal {

    private String nombre;

    public RecursoFiscal(String nombre) {
        this.nombre = nombre;
    }

    public String getNombre() {
        return nombre;
    }
}
