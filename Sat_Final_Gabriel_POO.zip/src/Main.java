
public class Main {

    public static void main(String[] args) {

        Rol administrador = new Rol("Administrador", true);
        Rol supervisor = new Rol("Supervisor", true);
        Rol auditor = new Rol("Auditor", false);

        Usuario gabriel = new Usuario("Gabriel", administrador);
        Usuario mariana = new Usuario("Mariana", supervisor);
        Usuario diana = new Usuario("Diana", auditor);

        RecursoFiscal declaraciones = new RecursoFiscal("Declaraciones");
        RecursoFiscal auditorias = new RecursoFiscal("Auditorias");

        SolicitudAcceso solicitud1 =
                new SolicitudAcceso(gabriel, declaraciones, "MODIFICAR");

        SolicitudAcceso solicitud2 =
                new SolicitudAcceso(mariana, auditorias, "VALIDAR");

        SolicitudAcceso solicitud3 =
                new SolicitudAcceso(diana, declaraciones, "CONSULTAR");

        SistemaFiscal sistema = new SistemaFiscal();

        sistema.procesarSolicitud(solicitud1);
        sistema.procesarSolicitud(solicitud2);
        sistema.procesarSolicitud(solicitud3);

        ReporteAuditoria reporte = new ReporteAuditoria();
        reporte.generarReporte();
    }
}
