
public class SistemaFiscal {

    public void procesarSolicitud(SolicitudAcceso solicitud) {

        System.out.println("--------------------------------");

        Usuario usuario = solicitud.getUsuario();

        System.out.println("Usuario: " + usuario.getNombre());
        System.out.println("Rol: " +
                usuario.getRol().getNombre());

        System.out.println("Recurso: " +
                solicitud.getRecurso().getNombre());

        System.out.println("Accion: " +
                solicitud.getAccion());

        String resultado;

        if (usuario.getRol().tienePermisoEspecial()) {

            resultado = "ACCESO PERMITIDO";
            System.out.println(resultado);

        } else {

            resultado = "ACCESO LIMITADO";
            System.out.println(resultado);
        }

        EventoAuditoria evento =
                new EventoAuditoria(
                        usuario.getNombre(),
                        solicitud.getAccion(),
                        resultado
                );

        evento.mostrarEvento();
    }
}
